export const nodeColor = {
  notVisitedCol: "rgb(255,255,255)",
  visitedCol: "rgb(100,255,255)",
  wallCol: "rgb(127,127,127)",
  startCol: "rgb(255,0,0)",
  endCol: "rgb(51,255,0)",
  discoveredCol: "rgb(4,180,255)",
  shortPath: "rgb(255,255,4)",
};
